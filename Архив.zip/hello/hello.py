from cs50 import get_string

answer = get_string("What is your name? ")

print(f"Hello, {answer}")
