def main():
    print("IoT Application is running!")

if __name__ == "__main__":
    main()
